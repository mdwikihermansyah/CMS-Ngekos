<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.boarding-house-resource.pages.create-boarding-house' => 'App\\Filament\\Resources\\BoardingHouseResource\\Pages\\CreateBoardingHouse',
    'app.filament.resources.boarding-house-resource.pages.edit-boarding-house' => 'App\\Filament\\Resources\\BoardingHouseResource\\Pages\\EditBoardingHouse',
    'app.filament.resources.boarding-house-resource.pages.list-boarding-houses' => 'App\\Filament\\Resources\\BoardingHouseResource\\Pages\\ListBoardingHouses',
    'app.filament.resources.category-resource.pages.create-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\CreateCategory',
    'app.filament.resources.category-resource.pages.edit-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\EditCategory',
    'app.filament.resources.category-resource.pages.list-categories' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\ListCategories',
    'app.filament.resources.city-resource.pages.create-city' => 'App\\Filament\\Resources\\CityResource\\Pages\\CreateCity',
    'app.filament.resources.city-resource.pages.edit-city' => 'App\\Filament\\Resources\\CityResource\\Pages\\EditCity',
    'app.filament.resources.city-resource.pages.list-cities' => 'App\\Filament\\Resources\\CityResource\\Pages\\ListCities',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => '/Users/mdwikihermansyah/Applications/learn_laravel/ngekos/app/Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    '/Users/mdwikihermansyah/Applications/learn_laravel/ngekos/app/Filament/Resources/BoardingHouseResource.php' => 'App\\Filament\\Resources\\BoardingHouseResource',
    '/Users/mdwikihermansyah/Applications/learn_laravel/ngekos/app/Filament/Resources/CategoryResource.php' => 'App\\Filament\\Resources\\CategoryResource',
    '/Users/mdwikihermansyah/Applications/learn_laravel/ngekos/app/Filament/Resources/CityResource.php' => 'App\\Filament\\Resources\\CityResource',
  ),
  'resourceDirectories' => 
  array (
    0 => '/Users/mdwikihermansyah/Applications/learn_laravel/ngekos/app/Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => '/Users/mdwikihermansyah/Applications/learn_laravel/ngekos/app/Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);